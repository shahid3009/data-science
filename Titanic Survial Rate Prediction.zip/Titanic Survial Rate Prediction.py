#!/usr/bin/env python
# coding: utf-8

# In[10]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# In[ ]:


'''Data Set Column Descriptions
pclass: Passenger Class (1 = 1st; 2 = 2nd; 3 = 3rd)
survived: Survival (0 = No; 1 = Yes)
name: Name
sex: Sex
age: Age
sibsp: Number of siblings/spouses aboard
parch: Number of parents/children aboard
fare: Passenger fare (British pound)
embarked: Port of embarkation (C = Cherbourg; Q = Queenstown; S = Southampton)
adult_male: A male 18 or older (0 = No, 1=Yes)
deck: Deck of the ship
who: man (18+), woman (18+), child (<18)
alive: Yes, no
embarked_town: Port of embarkation ( Cherbourg, Queenstown, Southampton)
class: Passenger class (1st; 2nd; 3rd)
alone: 1= alone, 0= not alone ( you have at least 1 sibling, spouse, parent or child on board)'''


# In[11]:


#load dataset
df = sns.load_dataset('titanic')
df.head()


# In[13]:


df.shape


# In[14]:


df.describe()


# In[15]:


df['survived'].value_counts()


# In[16]:


df.info()


# In[17]:


df.isnull().sum()


# In[18]:


#Look at all of the values in each column & get a count 
for val in df:
   print(df[val].value_counts())
   print()


# In[19]:


df =df.drop(labels=['deck','embark_town','alive','class','alone','adult_male','who'],axis=1)
df


# In[20]:


# filling the values 
df['age'].fillna((df['age'].mean()),inplace=True)
df =df.dropna(axis=0)
df.isnull().sum()


# In[21]:


df.shape


# In[22]:


#Print the unique values in the columns
print(df['sex'].unique())
print(df['embarked'].unique())


# In[46]:


from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()


# In[47]:


df['sex']=le.fit_transform(df['sex'])


# In[48]:


df.head()


# In[49]:


df['embarked']=le.fit_transform(df['embarked'])


# In[50]:


df.head()


# In[51]:


# A histogram is an accurate representation of the distribution of numerical data. It is an estimate of the probability distribution of a continuous variable.
df['sex'].hist() 


# In[52]:


df['age'].hist()


# In[54]:


sns.boxplot(df['age'])
plt.show()


# In[55]:


df.corr()


# In[56]:


corr = df.corr()
fig, ax = plt.subplots(figsize=(7,7))
sns.heatmap(corr , annot=True ,ax=ax)


# In[61]:


x = df.drop('survived',axis=1)
y = df['survived']


# In[62]:


print(x)


# In[63]:


x


# In[64]:


x.shape


# In[65]:


y


# In[66]:


y.shape


# In[71]:


from collections import Counter
print(Counter(y))
from imblearn.over_sampling import SMOTE
oversample = SMOTE(random_state = 7)
x , y = oversample.fit_resample(x , y)
print(Counter(y))


# In[72]:


x.shape


# In[73]:


from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
x_train ,x_test, y_train , y_test = train_test_split(x , y ,random_state=0,test_size=0.2)


# In[74]:


model=RandomForestClassifier()


# In[75]:


model.fit(x_train,y_train)


# In[76]:


prediction=model.predict(x_test)


# In[77]:


print(accuracy_score(y_test,prediction))


# In[78]:


from sklearn.linear_model import LogisticRegression
x_train ,x_test, y_train , y_test = train_test_split(x , y ,random_state=0,test_size=0.1)
model1 = LogisticRegression()


# In[79]:


model1.fit(x_train,y_train)


# In[80]:


prediction1=model1.predict(x_test)


# In[81]:


print(accuracy_score(y_test,prediction1))


# In[82]:


from sklearn.neighbors import KNeighborsClassifier
x_train ,x_test, y_train , y_test = train_test_split(x , y ,random_state=0,test_size=0.2)
model2= KNeighborsClassifier()


# In[83]:


model2.fit(x_train , y_train)


# In[84]:


prediction2=model2.predict(x_test)


# In[85]:


print(accuracy_score(y_test,prediction2))


# In[86]:


from sklearn.tree import DecisionTreeClassifier
x_train ,x_test, y_train , y_test = train_test_split(x , y ,random_state=0,test_size=0.2)
model3= DecisionTreeClassifier()


# In[87]:


model3.fit(x_train , y_train)


# In[88]:


prediction3=model3.predict(x_test)


# In[89]:


print(accuracy_score(y_test,prediction3))


# In[90]:


from sklearn.svm import SVC
x_train ,x_test, y_train , y_test = train_test_split(x , y ,random_state=0,test_size=0.2)
model4= SVC()


# In[91]:


model4.fit(x_train , y_train)


# In[92]:


prediction4=model4.predict(x_test)


# In[93]:


print(accuracy_score(y_test,prediction3))


# In[94]:


user_input=np.array([[3 , 1 , 22 , 1 , 0 , 7.25 ,2]])
prediction = model4.predict(user_input)
if prediction ==0:
    print("not survived")
else:
    print("survived")


# In[ ]:




